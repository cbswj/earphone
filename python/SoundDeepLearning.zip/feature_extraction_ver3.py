import glob
import librosa
import numpy as np


def extract_feature(file_name):
    X, sample_rate = librosa.load(file_name)
    stft = np.abs(librosa.stft(X)) # 단시간 푸리에 변환(Short-time Fourier Transform, STFT) https://darkpgmr.tistory.com/171
    mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T,axis=0)
    chroma = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T,axis=0)
    mel = np.mean(librosa.feature.melspectrogram(X, sr=sample_rate).T,axis=0)
    contrast = np.mean(librosa.feature.spectral_contrast(S=stft, sr=sample_rate).T,axis=0)
    tonnetz = np.mean(librosa.feature.tonnetz(y=librosa.effects.harmonic(X), sr=sample_rate).T,axis=0)
    return mfccs,chroma,mel,contrast,tonnetz

def parse_audio_files(filenames,n):
    rows = len(filenames)
    print(rows)

    features, labels, groups = np.zeros((rows,193)), np.zeros((rows,4)), np.zeros((rows, 1))
    i = 0
    for fn in filenames:
        # print( fn)
        # print(fn.split('/')[3].split('-')[1] )
        # group = int(fn.split('/')[3].split('-')[0].split('\\')[1])
        # print(group)
        if '복' in fn:
            y_col =3
            try:

                print('Y mute : ', y_col)

                group =10
                print(group)

                mfccs, chroma, mel, contrast, tonnetz = extract_feature(fn)
                ext_features = np.hstack([mfccs, chroma, mel, contrast,
                                          tonnetz])  # hstack 행의 수가 같은 두 개 이상의 배열을 옆으로 연결하여 열의 수가 더 많은 배열을 만든다

            except Exception  as e:
                print(fn + "     ERROR", e)
            else:
                features[i] = ext_features
                labels[i, y_col] = 1
                groups[i] = group
                i += 1

        else:


            y_col = int(fn.split('/')[3].split('-')[1])
            if (y_col in (1, 5, 8)):

                try:
                    print('Y 변환전 : ', y_col)
                    if y_col==5:
                        y_col-=4
                    elif y_col==8:
                        y_col-=6
                    else:
                        y_col-=1

                    print('Y 변환후 : ',y_col) ## 1=0, 5=1 ,5=2

                    group = int(fn.split('/')[3].split('-')[0].split('\\')[1])
                    print(group)


                    mfccs, chroma, mel, contrast,tonnetz = extract_feature(fn)
                    ext_features = np.hstack([mfccs,chroma,mel,contrast,tonnetz]) # hstack 행의 수가 같은 두 개 이상의 배열을 옆으로 연결하여 열의 수가 더 많은 배열을 만든다

                except Exception  as e:
                    print(fn+"     ERROR" , e)
                else:
                    features[i] = ext_features
                    labels[i, y_col] = 1
                    groups[i] = group
                    i += 1
    return features, labels, groups




audio_files = []
for i in range(1,12):


    audio_files.extend(glob.glob('UrbanSound8K/UrbanSound8K/audio/fold%d/*.wav' % i))   # extend는 가장 바깥쪽 iterable의 모든 항목을 대입
                    # glob 현재

#print(len(audio_files))
for i in range(0,11):
    files = audio_files[i*1000: (i+1)*1000]
    X, y, groups = parse_audio_files(files,i)
    for r in y:
        if np.sum(r) > 1.5:
            print('error occured')
            break
    np.savez('npz4/urban_sound_%d' % i, X=X, y=y, groups=groups)