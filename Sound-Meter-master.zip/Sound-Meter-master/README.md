# Sound-Meter
Sound-meter is an android application that measures sound level in decibel<br/>

![image](https://github.com/jeff2900/Sound-Meter/blob/master/screenshots/sm_en.jpg)<br>
<br/>
Based on halibobo's project
https://github.com/halibobo/SoundMeter<br/>
